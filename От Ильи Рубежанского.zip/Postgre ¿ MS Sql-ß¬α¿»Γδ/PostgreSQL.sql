-- select --1
-- 	emp.id as employee_id,
-- 	emp.name as employee_name,
-- 	emp.department_id as employee_department,
-- 	emp.salary as employee_salary,
-- 	chief.salary as chief_salary
-- from emplopyee emp
-- join emplopyee chief
-- 	on emp.chief_id = chief.id
-- where emp.salary<chief.salary
-- group by emp.department_id, emp.id, emp.name, emp.salary, chief.salary
-- order by emp.department_id, emp.salary


-- select --2
-- 	emp.id as employee_id,
-- 	emp.name as employee_name,
-- 	emp.department_id as employee_dep_id,
-- 	emp.salary as employee_salary
-- from emplopyee emp
-- join department dep
-- 	on emp.department_id = dep.id
-- where emp.salary = 
-- (
-- 	select
-- 		min(salary)
-- 	from emplopyee etemp
-- 	where etemp.department_id = emp.department_id
-- )


-- select --3
-- 	dep.id,
-- 	dep.depname,
-- 	count(emp.id) as employee_count
-- from department dep
-- join emplopyee emp
-- 	on dep.id = emp.department_id
-- group by dep.id,dep.depname
-- having count(emp.id) <= 3


-- select --4
-- 	emp.id,
-- 	emp.name,
-- 	emp.chief_id,
-- 	dep.id as department_id,
-- 	dep.depname as department_name
-- from emplopyee emp
-- join department dep
-- 	on emp.department_id = dep.id
-- where emp.chief_id is null


-- select --5
-- 	dep.id as department_id,
-- 	dep.depname as department_name,
-- 	sum(emp.salary) as max_salary_sum
-- from department dep
-- join emplopyee emp
-- 	on emp.department_id = dep.id
-- group by dep.id, dep.depname
-- having sum(emp.salary) =
-- (
-- 	select
-- 		max(summary)
-- 	from
-- 	(
-- 		select
-- 			sum(salary) summary
-- 		from emplopyee
-- 		group by department_id
-- 	) department_sum
-- )


-- select --6
-- 	dep.id as department_id,
-- 	dep.depname as department_name,
-- 	sum(emp.salary) as employees_salary_sum
-- from department dep
-- join emplopyee emp
-- 	on emp.department_id = dep.id
-- group by dep.id, dep.depname--, emp.chief_id
-- --having emp.chief_id is not null
-- order by dep.id, sum(emp.salary)


-- --function create
-- create or replace function UPDATESALARYFORDEPARTMENT
-- 	( id_of_department int,
-- 	  percent_salary_up decimal(10,2) )
-- returns table
-- 	(
-- 		employee_id int,
-- 		employee_name varchar,
-- 		employee_department_id int,
-- 		employee_chief_id int,
-- 		employee_old_salary decimal(10,2),
-- 		employee_new_salary decimal(10,2)
-- 	)
-- as $$
-- declare
-- 	max_employee_salary decimal(10,2);
-- 	chiefs_salary decimal(10,2);
-- 	chiefs_id int;
-- begin
	
-- 	select --filling vars
-- 		id,
-- 		cast(salary as decimal(10,2))
-- 	into chiefs_id, chiefs_salary
-- 	from emplopyee
-- 	where emplopyee.department_id = id_of_department
-- 		and emplopyee.chief_id is null;

-- 	--creating temp table for old salarys
-- 	create temp table emplopyee_old (	
-- 		employee_id int,
-- 		employee_salary decimal(10,2)
-- 	)
-- 	on commit drop;
	
-- 	insert into emplopyee_old --filling temp table
-- 	(employee_id, employee_salary)
-- 	select
-- 		id,
-- 		cast(salary as decimal(10,2))
-- 	from emplopyee
-- 	where emplopyee.department_id = id_of_department;

-- 	update emplopyee --setting new salarys
-- 	set salary = salary + cast(salary as decimal(10,2))*(percent_salary_up/100)
-- 	where emplopyee.department_id = id_of_department
-- 		and emplopyee.chief_id is not null;

-- 	select --finding max salary for employees, not chief
-- 		 max(emp.salary)
-- 	into max_employee_salary
-- 	from emplopyee emp
-- 	where emp.department_id = id_of_department
-- 		and emp.chief_id is not null;

-- 	if max_employee_salary > chiefs_salary then--checking is chiefs salary highest in department
-- 		update emplopyee
-- 		set salary = max_employee_salary
-- 		where emplopyee.department_id = id_of_department
-- 			and emplopyee.id = chiefs_id
-- 			and emplopyee.chief_id is null;
-- 	end if;

-- 	return query --returning finally result table
-- 		select
-- 			emp.id as employee_id,
-- 			emp.name as employee_name,
-- 			emp.department_id as employee_department_id,
-- 			emp.chief_id as employee_chief_id,
-- 			empT.employee_salary as employee_old_salary,
-- 			cast(emp.salary as decimal(10,2)) as employee_new_salary
-- 		from emplopyee emp
-- 		join emplopyee_old empT
-- 			on emp.id = empT.employee_id
-- 		where emp.department_id = id_of_department
-- 		order by emp.id;
	
-- 	end;
-- $$ language plpgsql;




-- select * from updatesalaryfordepartment(2, 15);


-- select * from emplopyee order by id;