--select
--emp.ID as 'ID',
--emp.NAME as 'NAME',
--emp.SALARY as 'SALARY',
--chief.SALARY as 'CHIEF_SALARY'
--from EMPLOYEE emp
--join EMPLOYEE chief
--on emp.CHIEF_ID = chief.ID
--where emp.SALARY < chief.SALARY

--select
--emp.ID as 'ID',
--emp.NAME as 'NAME',
--emp.SALARY as 'SALARY',
--dep.NAME as 'DEPARTMENT'
--from EMPLOYEE emp
--join DEPARTMENT dep
--on emp.DEPARTMENT_ID = dep.ID
--where emp.SALARY =
--(
--select min(SALARY)
--from EMPLOYEE empT
--where empT.DEPARTMENT_ID = dep.ID
--)

--select
--dep.ID as 'ID',
--count(emp.ID) as 'EMPLOYEE_COUNT'
--from DEPARTMENT dep
--join EMPLOYEE emp
--on emp.DEPARTMENT_ID = dep.ID
--group by dep.ID
--having count(emp.ID) <= 8

--select
--emp.NAME as 'NAME',
--emp.DEPARTMENT_ID as 'DEP_ID'
--from EMPLOYEE emp
--join DEPARTMENT dep
--on emp.DEPARTMENT_ID = dep.ID
--where emp.CHIEF_ID is null

--select 
--DEPARTMENT_ID,
--sum(SALARY) as total_salary
--from Employee
--where DEPARTMENT_ID is not null
--group by DEPARTMENT_ID
--having sum(SALARY) =
--(
--select max(total) 
--from
--(
--select sum(SALARY) as total
--from Employee
--where DEPARTMENT_ID is not null
--group by DEPARTMENT_ID
--) dept_totals
--);

--select
--dep.ID as department_id,
--dep.NAME as department_name,
--sum(emp.SALARY) as total_salary 
--from Department dep
--left join Employee emp 
--on dep.ID = emp.DEPARTMENT_ID
--group by dep.ID, dep.NAME
--order by dep.ID;

--create or alter procedure UPDATESALARYFORDEPARTMENT
--	@departID int,
--	@percentUp decimal(10,2)
--as
--begin
	
--	declare @chiefSalary int;
--	declare @maxEmployeeSalary int;
--	declare @chiefID int;
	
--	select
--		@chiefID = EMPLOYEE.ID,
--		@chiefSalary = EMPLOYEE.SALARY
--	from EMPLOYEE
--	where EMPLOYEE.DEPARTMENT_ID = @departID and EMPLOYEE.CHIEF_ID is null;

--	create table #employeeSalaryTemp
--		(
--			ID int not null,
--			OldSalary int
--		);

--	insert into #employeeSalaryTemp ([ID],[OldSalary])
--	select
--		EMPLOYEE.ID,
--		EMPLOYEE.SALARY
--	from EMPLOYEE
--	where EMPLOYEE.DEPARTMENT_ID = @departID;

--	update EMPLOYEE
--	set SALARY = SALARY + cast(SALARY as decimal(10,2))*(@percentUp/100)
--	where EMPLOYEE.DEPARTMENT_ID = @departID and EMPLOYEE.ID != @chiefID

--	select
--		@maxEmployeeSalary = max(EMPLOYEE.SALARY)
--	from EMPLOYEE
--	where EMPLOYEE.DEPARTMENT_ID = @departID and EMPLOYEE.ID != @chiefID;

--	if @maxEmployeeSalary > @chiefSalary
--	begin
--		update EMPLOYEE
--		set SALARY = @maxEmployeeSalary
--		where EMPLOYEE.ID = @chiefID
--	end;

--	select
--		emp.*,
--		old.OldSalary
--	from EMPLOYEE emp
--	left join #employeeSalaryTemp old
--	on emp.ID = old.ID
--	where emp.DEPARTMENT_ID = @departID;


--	drop table #employeeSalaryTemp;
--	end;

--exec UPDATESALARYFORDEPARTMENT
--	@departID = 1,
--	@percentUp = 50;